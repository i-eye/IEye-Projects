# About

A vanilla like(hopefully) mod that plans on adding what the imp expansion would have been. Planning on adding some regular items, a new item tier, 1 or 2 elite types, a new stage(probably stage 5), a new final stage and boss, more enemies, and more(?)!  
It's overambitious lol  
# Content
Wiki has detailed information(I'll try my best to update it)  
There are currently 2 items:
- 1 Common, 1 Lunar
# Bugs and stuff
Put them on the github or contact me on the modcord or dm(I_Eye#8095)  
If you have any feedback on the content too, I'd love to hear it. I don't want too crazy of items. 

Yes, there may be unneeded dependencies, cry about it  
Also, the config doesn't work I don't think, but I will be working on it   
And I can't guarantee that multiplayer will work, as it hasn't been tested  
# Translation
If you'd like to translate, contact me(I'll do Spanish though)  
- If my translation is bad and you have time, I'd love to hear feedback, I'm not a native Spanish speaker but I'm trying lol  
Also there are no plans for the wiki to be translated; however, most of the stuff should be avaliable in game, it'll just be a little less convenient(minus the tips and dev thoughts)  
# Credits  
Nebby and everyone on the Starstorm team for MSU and the loading scripts that I heavily referenced

Nightshade for creating the logo
# Changelog
### 0.0.5
- Added Spanish translation for
  - Expansion
  - 4D dagger
  - Double sided sword
- Added lore for the Double sided sword
- Updated the readme
- Made 4D dagger factor in luck

### 0.0.4
- Fixed some manifest stuff
- Made the depedencies more consistant across platforms
- Added spaces lol

### 0.0.3
- Fixed Double Sided Sword and added better descriptions
- 4D Dagger 30m radius -> 25m (+5m per stack)
- Added logo

### 0.0.2
Github Pre-release
- Added Double Sided Sword
- Added language/token support

### 0.0.1
Unreleased(you don't want it)
- Added Four Dimensional Dagger
- 4D Dagger 30m radius
- Mod actually is in game
