# About

A vanilla like(hopefully) mod that plans on adding what the imp expansion would have been. Planning on adding some regular items, a new item tier, 1 or 2 elite types, a new stage(probably stage 5), a new final stage and boss, more enemies, and more(?)!

It's overambitious lol

# Items
### White
- Four Dimensional Dagger: Bleed nearby enemies on hit

### Lunar
- Double Sided Sword: Bleed everything on damage taken

# Bugs
Put them on the github or contact me on the modcord or dm(I_Eye#8095)

If you'd like to translate, contact me(I'll do Spanish though)

# Credits  
Nebby and everyone on the Starstorm team for MSU and the loading scripts that I heavily referenced

Nightshade for creating the logo

# Changelog
### 0.0.3
- Fixed Double Sided Sword and added better descriptions
- 4D Dagger 30m radius -> 25m (+5m per stack)
- Added logo

### 0.0.2
Github Pre-release
- Added Double Sided Sword
- Added language/token support

### 0.0.1
Unreleased(you don't want it)
- Added Four Dimensional Dagger
- 4D Dagger 30m radius
- Mod actually is in game

