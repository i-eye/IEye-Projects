# About

A vanilla like(hopefully) mod that plans on adding what the imp expansion would have been. Planning on adding some regular items, a new item tier, 1 or 2 elite types, a new stage(probably stage 5), a new final stage and boss, more enemies, and more(?)!  
It's overambitious lol  
# Content
Wiki has more detailed information(I'll try my best to update it)  
There are currently 7 items:
- 1 Common, 1 Uncommon, 1 Lunar, and 4 of a new item tier: Sacrificial
There's also one interactable related to Sacrificial items
# Bugs and stuff
Put them on the github or contact me on the modcord or dm(i_eye on discord)
OR just join the discord server: https://discord.gg/Shd63mp4fB    
If you have any feedback on the content too, I'd love to hear it. I don't want too crazy of items. 
 
I can't guarantee that multiplayer will work, as it hasn't been tested    

Sacrifical items are soon to be reworked
# Translation
If you'd like to translate, contact me(I'll do Spanish though)  
- If my translation is bad and you have time, I'd love to hear feedback, I'm not a native Spanish speaker but estoy probando

# Credits  
Nebby for creating MSU and dealing with my stupid questions  
Everyone on the SS2 team for some great reference   
ihazkirbro for the sacrificial item tier idea  
F4UXX for helping with balance and creating some great stuff waiting to cross the in-between space  
QBanCaptain for helping with concept art and balance  
Buns and JestAnAnimator for help with some stuff preparing to cross from the Red Plane  
Nyctophiliac for creating the logo 

# Changelog

### 0.1.8
- Increased networking error checking for Bloody Prism

### 0.1.7
- More null checking for Insects

### 0.1.6
- Aggressive Insect no longer breaks things that take your health but aren't enemies(such as void cradles)
- Bloody Prism is more consistent and more dangerous

### 0.1.5
- Updated for SOTS
  - MSU2.0 LET'S GO
- Reworked Introspective Insect
  - 50% decrease both speeds
  - 5 hits
  - 5% max Health
  - 7 seconds (+7 seconds per stack)
- Reworked Aggressive Insect
  - 8 seconds
  - 25% total damage (+25% per stack)
  - .2 proc chance
  - New VFX + SFX
- Spoiler Artifact(It's a fun one)(code will be implemented in game at some point, don't worry)
  - Code on wiki

### 0.1.4
- New Bloody Prism
  - New shape, size, and particles
  - See your loot before you summon a challengeing horde or enemies, which has 50% chance of being imps now
  - Director Credit Cost -> 35
  - ImpStuff Interactble Catagory Weight 1.9 -> 2.8
  - Miniumum Stage Completion 0 -> 1
- Sacrifice 
  - Added UI effect for Transitions!
- Introspective Insect Lore by ihazkirbro
  
### 0.1.3
- Lowered selection weight for bloody prism from 3.2 to 1.9
- Increased sacrificial kill coeffecient from 2.2 to 3.8
- Fixed a typo

### 0.1.2 I literally just recompiled it
- Updated to director api 2.0

### 0.1.1
- Fixed bloody prisms just popping the item out after enough teleporter enemies are killed
  - Side effect/probably gonna be kept - can't be activated after teleporter

### 0.1.0
- New 4D dagger model
- Introspective Insect added
  - Duration 10s
  - Damage reduction 20%
  - Health calculation complication but increases on stack(3 / (1.1 + (.1 * stack))) health
- Sacrificial item tier added
  - SacrificialHelper hidden item used
- Risk of Options support(TY NEBBY!)
- Aggressive Insect added - inflicts debuff on hit
  - Duration 3s (+3s per stack)
  - Damage reduction 5%
  - Armor reduction 25
- Adrenaline Frenzy added
  - 6% (+4% per stack) sprint speed on kill for 10s
  - 12% (+7% per stack) speed on getting hit for 8s
- Focused Hemorrhage added
  - 10% chance on hit to cause stack instances of hemorrhage for 15s with 135% percent damage coefficient
- Predatory Savagery added - gives buff on hit/kill
  - 15 armor per stack
  - 15% damage per stack
  - 5% cooldown reduction per stack(up to 50%)
  - 35% added jump power
  - 10% crit damage per stack
  - 6% crit chance
  - 10s (+3s on stack) duration
  - 2% chance to get buff on hit
  - 8% chance to get buff on kill
- Bloody Prism added

### 0.0.5
- Added Spanish translation for
  - Expansion
  - 4D dagger
  - Double sided sword
- Added lore for the Double sided sword
- Updated the readme
- Made 4D dagger factor in luck

### 0.0.4
- Fixed some manifest stuff
- Made the depedencies more consistant across platforms
- Added spaces lol

### 0.0.3
- Fixed Double Sided Sword and added better descriptions
- 4D Dagger 30m radius -> 25m (+5m per stack)
- Added logo

### 0.0.2
Github Pre-release
- Added Double Sided Sword
- Added language/token support

### 0.0.1
Unreleased(you don't want it)
- Added Four Dimensional Dagger
- 4D Dagger 30m radius
- Mod actually is in game


